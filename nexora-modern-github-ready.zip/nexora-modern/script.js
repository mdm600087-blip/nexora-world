(() => {
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
  const toast = $('#toast');
  let toastTimer;
  function notify(message) {
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
  }

  // The account dialog is a front-end demo; connect it to a secure backend before production.
  const dialog = $('#authDialog');
  let authMode = 'signup';
  function setAuthMode(mode) {
    authMode = mode;
    $$('.dialog-tab').forEach(tab => tab.classList.toggle('active', tab.dataset.tab === mode));
    $('#nameField').hidden = mode === 'login';
    $('#fullName').required = mode === 'signup';
    $('#dialogTitle').textContent = mode === 'signup' ? 'Create your account' : 'Welcome back';
    $('#dialogDescription').textContent = mode === 'signup' ? "Join the conversation — it's free." : 'Log in to continue to your space.';
    $('#authSubmit').innerHTML = mode === 'signup' ? 'Create account <span>→</span>' : 'Log in <span>→</span>';
    $('#password').autocomplete = mode === 'signup' ? 'new-password' : 'current-password';
  }
  function openAuth(mode) {
    setAuthMode(mode || 'signup');
    if (typeof dialog.showModal === 'function') dialog.showModal();
    else notify('Your browser does not support this dialog. Please update your browser.');
  }
  $$('[data-auth]').forEach(button => button.addEventListener('click', event => {
    event.preventDefault();
    openAuth(button.dataset.auth);
  }));
  $$('.dialog-tab').forEach(tab => tab.addEventListener('click', () => setAuthMode(tab.dataset.tab)));
  $('#closeDialog').addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => {
    if (event.target === dialog) dialog.close();
  });
  $('#authForm').addEventListener('submit', event => {
    event.preventDefault();
    const email = $('#email').value.trim();
    const password = $('#password').value;
    const name = $('#fullName').value.trim();
    if (password.length < 8) {
      notify('Password must be at least 8 characters.');
      return;
    }
    // No credentials are sent or stored. This intentionally demonstrates the UI only.
    dialog.close();
    notify(authMode === 'signup'
      ? `Thanks${name ? ', ' + name : ''}! Connect an authentication backend to create your account.`
      : `Welcome back! Connect an authentication backend to log in (${email}).`);
    $('#authForm').reset();
  });

  // Live client-side search across the demo feed.
  const search = $('#globalSearch');
  const posts = $$('.searchable-post');
  const emptyState = $('#emptyState');
  function filterPosts() {
    const term = (search.value || '').trim().toLowerCase();
    let visible = 0;
    posts.forEach(post => {
      const content = ((post.innerText || '') + ' ' + (post.dataset.keywords || '')).toLowerCase();
      const matches = !term || content.includes(term);
      post.hidden = !matches;
      if (matches) visible++;
    });
    emptyState.hidden = visible !== 0;
  }
  search.addEventListener('input', filterPosts);
  search.addEventListener('keydown', event => {
    if (event.key === 'Enter') {
      $('#feed').scrollIntoView({ behavior: 'smooth' });
      filterPosts();
    }
  });

  // Like buttons toggle a local visual state. Counts are demo data and reset on reload.
  $$('.like-button').forEach(button => button.addEventListener('click', () => {
    const liked = button.classList.toggle('liked');
    button.querySelector('span').textContent = liked ? '♥' : '♡';
    button.lastChild.textContent = liked ? ' Liked' : ' Like';
    const count = button.closest('.post-card').querySelector('.like-count');
    const current = Number(count.textContent) || 0;
    count.textContent = String(current + (liked ? 1 : -1));
    notify(liked ? 'You liked this post.' : 'Like removed.');
  }));
  $$('.comment-button').forEach(button => button.addEventListener('click', () => {
    notify('Comments are a preview in this demo. Sign up to join the conversation.');
  }));
  $$('.share-button').forEach(button => button.addEventListener('click', async () => {
    const shareData = { title: 'NEXORA', text: 'Check out this post on NEXORA', url: location.href };
    if (navigator.share) {
      try { await navigator.share(shareData); } catch (error) { if (error.name !== 'AbortError') notify('Sharing is unavailable right now.'); }
    } else if (navigator.clipboard && navigator.clipboard.writeText) {
      try { await navigator.clipboard.writeText(location.href); notify('Page link copied to clipboard.'); }
      catch { notify('Copy this page URL from your browser address bar to share it.'); }
    } else {
      notify('Copy this page URL from your browser address bar to share it.');
    }
  }));
  $$('.post-menu').forEach(button => button.addEventListener('click', () => notify('Post menu is a UI preview.')));
  $$('[data-story]').forEach(button => button.addEventListener('click', () => notify(`${button.dataset.story}'s story preview is coming soon.`)));
  $('#viewStories').addEventListener('click', event => { event.preventDefault(); notify('You are viewing the available story previews.'); });
  $('#sortButton').addEventListener('click', () => notify('You are viewing sample posts selected for you.'));

  const mobileMenu = $('#mobileMenu');
  const nav = $('#mainNav');
  mobileMenu.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    mobileMenu.setAttribute('aria-expanded', String(open));
    mobileMenu.textContent = open ? '×' : '☰';
  });
  $$('.main-nav a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    mobileMenu.setAttribute('aria-expanded', 'false');
    mobileMenu.textContent = '☰';
  }));
  $('#year').textContent = new Date().getFullYear();
})();